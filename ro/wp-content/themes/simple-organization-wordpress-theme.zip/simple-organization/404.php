<?php get_header(); ?>

			<h1>Error - Page Not Found</h1>

			<div class="title-description">The page or post you were looking for does not exist or has been moved to another location.</div>

		<?php get_sidebar(); ?>

<?php get_footer(); ?>