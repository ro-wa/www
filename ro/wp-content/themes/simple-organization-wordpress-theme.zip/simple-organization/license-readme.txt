>> Usage
-------------------------------------------------
1) Logo - Replace "logo.gif" and "logo-small.gif" located in the img folder.
2) Edit "splash.php" which contains the three columns shown at frontpage. Delete "splash.php" to remove them.


>> License
-------------------------------------------------
This template/theme is licensed under a GPL license: http://www.gnu.org/licenses/gpl.html


>> Author
-------------------------------------------------
Author: Viktor Persson
Website: http://arcsin.se/


>> More templates & themes
-------------------------------------------------
Arcsin Web Templates: http://templates.arcsin.se/