<div id="splash">

	<div class="col3 left">
		
		<h2 class="label label-green">Mission Statement</h2>

		<p class="quiet large">What we want to achieve</p>

		<p>Vestibulum eu pellentesque ante. Sed tincidunt quam eu nisl luctus id mattis tellus rhoncus.</p>
		<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae. Donec dapibus eros vitae nibh venenatis faucibus.</p>
		<p><a href="#" class="more">Learn more &raquo;</a></p>

	</div>

	<div class="col3-mid left">
		
		<h2 class="label label-orange">Next Event</h2>

		<p class="quiet large">Friday, August 18, 2009</p>

		<p><img src="<?php bloginfo('stylesheet_directory'); ?>/img/sample-event.jpg" width="240" height="80" alt="" class="bordered" /></p>
		<p><em>Aliquam augue neque, rhoncus et dictum in, cursus eget mauris.</em></p>

	</div>

	<div class="col3 right">
		
		<h2 class="label label-blue">Follow Us</h2>

		<p class="quiet large">http://twitter.com/username</p>

		<p>Nulla mollis sollicitudin nulla et mattis.<span class="quiet">(2 hours ago)</span></p>
		<p>Torquent per conubia nostra, per inceptos himenaeos. <span class="quiet">(2 hours ago)</span></p>
		<p>In sed ante at velit hendrerit blandit a et nibh. Cras sed cursus nulla. <span class="quiet">(3 hours ago)</span></p>
		<p>Nullam vitae mi at nulla blandit. <span class="quiet">(5 hours ago)</span></p>

	</div>

	<div class="clearer">&nbsp;</div>

</div>